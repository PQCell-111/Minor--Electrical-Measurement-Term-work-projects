(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b5d341a5._.js",
  "static/chunks/node_modules_lodash_f240f67a._.js",
  "static/chunks/node_modules_recharts_es6_ccade03f._.js",
  "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cdad.js",
  "static/chunks/node_modules_@radix-ui_95ce222c._.js",
  "static/chunks/node_modules_@floating-ui_9ec1fa39._.js",
  "static/chunks/node_modules_d397f877._.js"
],
    source: "dynamic"
});
