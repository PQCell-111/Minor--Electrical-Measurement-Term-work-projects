
  # CSV to Graphical Visualization

  This is a code bundle for CSV to Graphical Visualization. The original project is available at https://www.figma.com/design/EZj6maGtsEbRgh8v7t5sl3/CSV-to-Graphical-Visualization.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  