(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_67176ada._.js",
  "static/chunks/node_modules_lodash_f240f67a._.js",
  "static/chunks/node_modules_recharts_es6_ccade03f._.js",
  "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cdad.js",
  "static/chunks/node_modules_90b51d36._.js"
],
    source: "dynamic"
});
